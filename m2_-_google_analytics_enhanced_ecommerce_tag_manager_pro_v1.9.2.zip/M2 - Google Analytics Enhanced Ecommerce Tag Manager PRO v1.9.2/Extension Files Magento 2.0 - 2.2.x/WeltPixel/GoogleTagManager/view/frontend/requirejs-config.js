var config = {
    map: {
        '*': {
            weltpixel_gtm: 'WeltPixel_GoogleTagManager/js/weltpixel_gtm',
            weltpixel_persistentLayer: 'WeltPixel_GoogleTagManager/js/weltpixel_persistentlayer'
        }
    }
};