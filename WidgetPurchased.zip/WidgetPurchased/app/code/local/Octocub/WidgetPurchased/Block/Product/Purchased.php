<?php
class Octocub_WidgetPurchased_Block_Product_Purchased extends Mage_Catalog_Block_Product_Abstract implements Mage_Widget_Block_Interface
{
    protected $customerId = null;
    protected $product = null;
    protected $collection = null;

    protected function getCustomerId()
    {
        if(!$this->customerId)
            $this->customerId = Mage::getSingleton('customer/session')->getCustomerId();

        return $this->customerId;
    }

    public function getItemsCollection()
    {
        if(!$this->collection)
        {
            $this->collection = Mage::getMOdel("sales/order_item")->getCollection();
            $this->collection->getSelect()->where("product_id = ". $this->getProduct()->getId())->order("created_at desc");
        }
        return $this->collection;
    }

    public function getProduct()
    {
        $this->product = Mage::registry('current_product');
        if ($this->product) {
            return $this->product;
        }
        return null;
    }

    public function getPurchaseCount()
    {
        $orderIds = $this->getItemsCollection()->getColumnValues('order_id');
        return count(array_unique($orderIds));
    }

    public function getLastPurchasedAt()
    {
        $item = $this->getItemsCollection()->getFirstItem();
        return date("F d, Y", strtotime($item->getCreatedAt()));
    }

    public function getLastOrderUrl()
    {
        $item = $this->getItemsCollection()->getFirstItem();
        return Mage::getUrl("sales/order/view", ['order_id' => $item->getOrderId()]);
    }

    public function getOrderItem()
    {
        return $item = $this->getItemsCollection()->getFirstItem();
    }

    public function getItemOptions()
    {
        $result = array();
        if ($options = $this->getOrderItem()->getProductOptions()) {
            if (isset($options['options'])) {
                $result = array_merge($result, $options['options']);
            }
            if (isset($options['additional_options'])) {
                $result = array_merge($result, $options['additional_options']);
            }
            if (isset($options['attributes_info'])) {
                $result = array_merge($result, $options['attributes_info']);
            }
        }
        return $result;
    }

    public function getFormatedOptionValue($optionValue)
    {
        $optionInfo = array();

        // define input data format
        if (is_array($optionValue)) {
            if (isset($optionValue['option_id'])) {
                $optionInfo = $optionValue;
                if (isset($optionInfo['value'])) {
                    $optionValue = $optionInfo['value'];
                }
            } elseif (isset($optionValue['value'])) {
                $optionValue = $optionValue['value'];
            }
        }

        // render customized option view
        if (isset($optionInfo['custom_view']) && $optionInfo['custom_view']) {
            $_default = array('value' => $optionValue);
            if (isset($optionInfo['option_type'])) {
                try {
                    $group = Mage::getModel('catalog/product_option')->groupFactory($optionInfo['option_type']);
                    return array('value' => $group->getCustomizedView($optionInfo));
                } catch (Exception $e) {
                    return $_default;
                }
            }
            return $_default;
        }

        // truncate standard view
        $result = array();
        if (is_array($optionValue)) {
            $_truncatedValue = implode("\n", $optionValue);
            $_truncatedValue = nl2br($_truncatedValue);
            return array('value' => $_truncatedValue);
        } else {
            $_truncatedValue = Mage::helper('core/string')->truncate($optionValue, 55, '');
            $_truncatedValue = nl2br($_truncatedValue);
        }

        $result = array('value' => $_truncatedValue);

        if (Mage::helper('core/string')->strlen($optionValue) > 55) {
            $result['value'] = $result['value'] . ' <a href="#" class="dots" onclick="return false">...</a>';
            $optionValue = nl2br($optionValue);
            $result = array_merge($result, array('full_view' => $optionValue));
        }

        return $result;
    }

    protected function _toHtml()
    {
        if(!$this->getCustomerId()){
            return '';
        }

        if (!Mage::registry('current_product')) {
            return '';
        }

        if(!$this->getItemsCollection())
            return '';

        if($this->getItemsCollection()->getSize() <= 0)
            return '';

        return parent::_toHtml();
    }
}
