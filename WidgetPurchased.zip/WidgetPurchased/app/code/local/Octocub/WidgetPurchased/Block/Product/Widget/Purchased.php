<?php
class Octocub_WidgetPurchased_Block_Product_Widget_Purchased extends Octocub_WidgetPurchased_Block_Product_Purchased implements Mage_Widget_Block_Interface
{
    /**
     * Internal constructor
     *
     */
    protected function _construct()
    {
        parent::_construct();
        $this->addColumnCountLayoutDepend('one_column', 5)
            ->addColumnCountLayoutDepend('two_columns_left', 4)
            ->addColumnCountLayoutDepend('two_columns_right', 4)
            ->addColumnCountLayoutDepend('three_columns', 3);
    }
}
